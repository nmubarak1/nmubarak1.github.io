<?php

if( !function_exists('k_teacher_filter_bar_shortcode') ) {
    function k_teacher_filter_bar_shortcode($atts)
    {
        $attr = shortcode_atts( array(
            'list' => '',
        ), $atts );

        if($attr['list'] == ''){
            $attr['list'] = str_split( 'ABCDEFGHIJKLMNOPQRSTUVWXYZ');
        }

        return k2t_get_template_part('teacher', 'filter-bar', array('list' => $attr['list']));

    }

    add_shortcode('k_teacher_filter_bar', 'k_teacher_filter_bar_shortcode');
}